#ifndef DATABASEHEADER_H
#define DATABASEHEADER_H

#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QDebug>
#include <QSqlTableModel>
#include <QFile>

#endif // DATABASEHEADER_H
